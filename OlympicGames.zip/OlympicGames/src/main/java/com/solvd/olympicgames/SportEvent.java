package main.java.com.solvd.olympicgames;

public class SportEvent {
 public void main(String[] args){
     static String[] SportEvent = {"(1) Baseball", "(2) Basketball", "(3) Swimming", "(4) Volleyball" };


     System.out.println("SportEvent");

 }
}
