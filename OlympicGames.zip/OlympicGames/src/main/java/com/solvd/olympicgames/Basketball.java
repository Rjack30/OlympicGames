package main.java.com.solvd.olympicgames;
    abstract public class Basketball {
        public void main(String[] arga){

        }
}
        private int 3pointer;

        private int 2pointer;

        private int layup count = 2;

        private int TeamScores = 34;

        private int points = 0;

        private int 4quaters = 48mins;